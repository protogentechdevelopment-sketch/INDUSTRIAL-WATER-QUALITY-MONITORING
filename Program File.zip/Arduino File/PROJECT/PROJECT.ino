/*
  Water Tank Monitor — ESP32 + ST7735 160×128 LANDSCAPE
  Exact port of the HTML canvas UI.

  Libraries needed (install via Library Manager):
    Adafruit ST7735 and ST7789 Library
    Adafruit GFX Library
    OneWire
    DallasTemperature

  Wiring:
    ST7735  → ESP32
    CS      → GPIO 5
    DC      → GPIO 2
    RST     → GPIO 4
    MOSI    → GPIO 23  (SPI default)
    SCK     → GPIO 18  (SPI default)

    DS18B20 → GPIO 25
    TRIG    → GPIO 26
    ECHO    → GPIO 27
    TDS     → GPIO 34 (ADC)

  Set DEMO_MODE 1 to run without any sensors wired.
*/

#include <Adafruit_GFX.h>
#include <Adafruit_ST7735.h>
#include <SPI.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <math.h>

// ── DEMO MODE ────────────────────────────────────────────────────────────────
#define DEMO_MODE   0   // set 0 when sensors are wired

// ── PIN MAP ───────────────────────────────────────────────────────────────────
#define TFT_CS      5
#define TFT_DC      2
#define TFT_RST     4
#define DS18B20_PIN 25
#define TRIG_PIN    26
#define ECHO_PIN    27
#define TDS_PIN     34
#define RED_LED    12
#define GREEN_LED  14

// ── THRESHOLDS ────────────────────────────────────────────────────────────────
#define TANK_EMPTY_CM  10.5f
#define TANK_FULL_CM    3.0f
#define TDS_SAFE   300
#define TDS_WARN   600
#define TEMP_COLD   15.0f
#define TEMP_HOT    33.0f

// ── TIMING ────────────────────────────────────────────────────────────────────
#define SENSOR_MS  2000
#define WAVE_MS      55

// ── LAYOUT (matches HTML exactly) ────────────────────────────────────────────
// Screen: 160 wide × 128 tall (landscape, setRotation(1))
// Tank left column
#define TX   2
#define TY   4
#define TW  82
#define TH 120
// Water viewport
#define WX  (TX+4)
#define WY  (TY+4)
#define WW  (TW-8)
#define WH  (TH-8)
// Info panel right column
#define IX   91
#define IW  (159-IX)   // = 68

// ── RGB888 → RGB565 helper ────────────────────────────────────────────────────
#define RGB(r,g,b) ( ((uint16_t)((r)&0xF8)<<8) | ((uint16_t)((g)&0xFC)<<3) | ((uint16_t)((b)>>3) ) )

// ── COLOUR PALETTE (matches HTML palette exactly) ─────────────────────────────
// Background / structure
const uint16_t C_BG     = RGB(4,  12,  4);
const uint16_t C_PANEL  = RGB(6,  18,  8);
const uint16_t C_DIV    = RGB(20, 60, 24);
const uint16_t C_AIR    = RGB(6,  14,  6);
const uint16_t C_PANEL2 = RGB(10, 30, 12);

// Chrome
const uint16_t C_RIM    = RGB(12, 50, 16);
const uint16_t C_RIM2   = RGB(30, 90, 36);
const uint16_t C_RIB    = RGB(10, 70, 18);
const uint16_t C_RIBHI  = RGB(20,180, 40);
const uint16_t C_RIVET  = RGB(16, 90, 24);
const uint16_t C_RIVHI  = RGB(40,200, 60);
const uint16_t C_SCALE  = RGB(30, 80, 36);
const uint16_t C_SCALEA = RGB(0, 220,100);

// Pipe colours
const uint16_t C_PIPEIN = RGB(0,  80,160);
const uint16_t C_PIPEOUT= RGB(160,50,  0);
const uint16_t C_PIPEDRAIN=RGB(40,80, 44);

// Tank inner chrome
const uint16_t C_INNER  = RGB(40,120, 50);

// Water — safe (blue-green)
const uint16_t C_WSD    = RGB(0,  80,180);
const uint16_t C_WSM    = RGB(0, 120,220);
const uint16_t C_WST    = RGB(30,180,255);
const uint16_t C_WSF    = RGB(120,240,255);

// Water — warn (amber)
const uint16_t C_WWD    = RGB(120, 80,  0);
const uint16_t C_WWM    = RGB(180,120,  0);
const uint16_t C_WWT    = RGB(230,170, 20);
const uint16_t C_WWF    = RGB(255,220, 80);

// Water — danger (red)
const uint16_t C_WDD    = RGB(140, 20, 10);
const uint16_t C_WDM    = RGB(190, 50, 20);
const uint16_t C_WDT    = RGB(230, 90, 40);
const uint16_t C_WDF    = RGB(255,140, 60);

// Info panel
const uint16_t C_HDR    = RGB(0, 200,100);
const uint16_t C_LBL    = RGB(40,160, 50);
const uint16_t C_LVLV   = RGB(0, 230,180);
const uint16_t C_LVLB   = RGB(0, 100, 80);
const uint16_t C_TMPOK  = RGB(255,200,  0);
const uint16_t C_TMPC   = RGB(60, 140,255);
const uint16_t C_TMPH   = RGB(255, 40, 20);
const uint16_t C_TDSS   = RGB(0,  220, 60);
const uint16_t C_TDSW   = RGB(255,200,  0);
const uint16_t C_TDSD   = RGB(255, 40, 20);
const uint16_t C_TBS    = RGB(0,  100, 40);
const uint16_t C_TBW    = RGB(160, 90,  0);
const uint16_t C_TBD    = RGB(140, 20, 10);
const uint16_t C_MK     = RGB(80, 255,220);
const uint16_t C_DIM    = RGB(40,  80, 44);
const uint16_t C_HDR_BG = RGB(0,   30, 10);
const uint16_t C_BAR_BG = RGB(8,   20, 10);
const uint16_t C_WHITE  = RGB(255,255,255);

// ── 5×5 PIXEL FONT ───────────────────────────────────────────────────────────
// Each character: 5 rows × 5 cols, packed as 5 bytes (bit4=leftmost pixel)
// Matches the HTML FONT table exactly.
struct Glyph { uint8_t rows[5]; };

const Glyph FONT[] PROGMEM = {
  // index 0 = ' ' (space)
  {{0x00,0x00,0x00,0x00,0x00}},  // ' '
  // digits 0-9  (index 1-10)
  {{0x06,0x09,0x09,0x09,0x06}},  // '0'  0110 1001 1001 1001 0110
  {{0x02,0x06,0x02,0x02,0x07}},  // '1'
  {{0x06,0x09,0x02,0x04,0x0F}},  // '2'
  {{0x0E,0x01,0x06,0x01,0x0E}},  // '3'
  {{0x05,0x05,0x0F,0x01,0x01}},  // '4'
  {{0x0F,0x08,0x0E,0x01,0x0E}},  // '5'
  {{0x07,0x08,0x0E,0x09,0x06}},  // '6'
  {{0x0F,0x01,0x02,0x04,0x08}},  // '7'
  {{0x06,0x09,0x06,0x09,0x06}},  // '8'
  {{0x06,0x09,0x07,0x01,0x06}},  // '9'
  // uppercase A-Z  (index 11-36)
  {{0x06,0x09,0x0F,0x09,0x09}},  // 'A'
  {{0x0E,0x09,0x0E,0x09,0x0E}},  // 'B'
  {{0x07,0x08,0x08,0x08,0x07}},  // 'C'
  {{0x0E,0x09,0x09,0x09,0x0E}},  // 'D'
  {{0x0F,0x08,0x0E,0x08,0x0F}},  // 'E'
  {{0x0F,0x08,0x0E,0x08,0x08}},  // 'F'
  {{0x07,0x08,0x0B,0x09,0x07}},  // 'G'
  {{0x09,0x09,0x0F,0x09,0x09}},  // 'H'
  {{0x07,0x02,0x02,0x02,0x07}},  // 'I'
  {{0x01,0x01,0x01,0x09,0x06}},  // 'J'
  {{0x09,0x0A,0x0C,0x0A,0x09}},  // 'K'
  {{0x08,0x08,0x08,0x08,0x0F}},  // 'L'
  {{0x11,0x1B,0x15,0x11,0x11}},  // 'M' (5-bit)
  {{0x09,0x0D,0x0B,0x09,0x09}},  // 'N'
  {{0x06,0x09,0x09,0x09,0x06}},  // 'O'
  {{0x0E,0x09,0x0E,0x08,0x08}},  // 'P'
  {{0x06,0x09,0x09,0x09,0x07}},  // 'Q'
  {{0x0E,0x09,0x0E,0x0A,0x09}},  // 'R'
  {{0x07,0x08,0x06,0x01,0x0E}},  // 'S'
  {{0x1F,0x04,0x04,0x04,0x04}},  // 'T' (5-bit)
  {{0x09,0x09,0x09,0x09,0x06}},  // 'U'
  {{0x11,0x11,0x0A,0x0A,0x04}},  // 'V' (5-bit)
  {{0x11,0x11,0x15,0x1B,0x11}},  // 'W' (5-bit)
  {{0x09,0x06,0x00,0x06,0x09}},  // 'X'
  {{0x09,0x06,0x02,0x02,0x02}},  // 'Y'
  {{0x0F,0x01,0x02,0x04,0x0F}},  // 'Z'
  // special  (index 37+)
  {{0x00,0x00,0x00,0x00,0x02}},  // '.'  index 37
  {{0x00,0x02,0x00,0x02,0x00}},  // ':'  index 38
  {{0x09,0x02,0x02,0x04,0x09}},  // '%'  index 39
  {{0x06,0x06,0x00,0x00,0x00}},  // '°'  index 40
  {{0x00,0x0E,0x09,0x0E,0x08}},  // 'p' (lowercase) index 41
  {{0x00,0x00,0x00,0x00,0x04}},  // '!' index 42  (dot only for compactness)
  {{0x00,0x00,0x07,0x00,0x00}},  // '-' index 43
};

// Lookup: returns index into FONT array for a character
int fontIdx(char ch){
  if(ch==' ') return 0;
  if(ch>='0'&&ch<='9') return 1+(ch-'0');
  if(ch>='A'&&ch<='Z') return 11+(ch-'A');
  if(ch>='a'&&ch<='z') return 11+(ch-'a');  // treat lower as upper except p
  if(ch=='p') return 41;
  if(ch=='.') return 37;
  if(ch==':') return 38;
  if(ch=='%') return 39;
  if(ch=='\xB0'||ch=='*') return 40; // degree symbol
  if(ch=='!') return 42;
  if(ch=='-') return 43;
  return 0;
}

// ── OBJECTS ───────────────────────────────────────────────────────────────────
Adafruit_ST7735 tft(TFT_CS, TFT_DC, TFT_RST);
OneWire         oneWire(DS18B20_PIN);
DallasTemperature tempSensor(&oneWire);

// ── STATE ─────────────────────────────────────────────────────────────────────
float gLevel   = 10.0f;   // 0-100 %
float gTemp    = 28.0f;   // °C
float gTDS     = 180.0f;  // ppm
float gDistCm  = 14.0f;
int   wavePhase= 0;
bool  firstDraw= true;
unsigned long lastSensor=0, lastWave=0;

// ── COLOUR SELECTORS ─────────────────────────────────────────────────────────
uint16_t wDeep(){ return gTDS<TDS_SAFE?C_WSD:gTDS<TDS_WARN?C_WWD:C_WDD; }
uint16_t wMid() { return gTDS<TDS_SAFE?C_WSM:gTDS<TDS_WARN?C_WWM:C_WDM; }
uint16_t wTop() { return gTDS<TDS_SAFE?C_WST:gTDS<TDS_WARN?C_WWT:C_WDT; }
uint16_t wFoam(){ return gTDS<TDS_SAFE?C_WSF:gTDS<TDS_WARN?C_WWF:C_WDF; }
uint16_t tCol() { return gTemp<=TEMP_COLD?C_TMPC:gTemp>=TEMP_HOT?C_TMPH:C_TMPOK; }
uint16_t dCol() { return gTDS>=TDS_WARN?C_TDSD:gTDS>=TDS_SAFE?C_TDSW:C_TDSS; }

// Level bar colour
uint16_t lvlBarCol(){
  return gLevel<30 ? C_TDSD : gLevel<60 ? C_TDSW : C_LVLB;
}

// ── SAFE PIXEL (clipped to water viewport) ────────────────────────────────────
inline void safePixel(int x, int y, uint16_t c){
  if(x>=WX && x<WX+WW && y>=WY && y<WY+WH)
    tft.drawPixel(x,y,c);
}

// ── PIXEL FONT DRAW ───────────────────────────────────────────────────────────
void drawChar(char ch, int cx, int cy, uint16_t col){
  int idx = fontIdx(ch);
  for(int row=0; row<5; row++){
    uint8_t bits = pgm_read_byte(&FONT[idx].rows[row]);
    for(int col2=0; col2<5; col2++){
      if(bits & (0x10 >> col2))
        tft.drawPixel(cx+col2, cy+row, col);
    }
  }
}

void drawText(const char* str, int x, int y, uint16_t col){
  int cx = x;
  while(*str){
    drawChar(*str, cx, y, col);
    cx += 6;
    str++;
  }
}

// ── BACKGROUND ────────────────────────────────────────────────────────────────
void drawBackground(){
  tft.fillScreen(C_BG);
  // Subtle scanlines on tank area
  for(int y=0; y<128; y+=8)
    tft.drawFastHLine(0, y, TX+TW, C_AIR);
  // Info panel
  tft.fillRect(IX-2, 0, IW+3, 128, C_PANEL);
  tft.drawFastVLine(IX-3, 0, 128, C_DIV);
  tft.drawFastVLine(IX-2, 0, 128, C_PANEL2);
}

// ── TANK CHROME ───────────────────────────────────────────────────────────────
void drawTankChrome(){
  // Inlet pipe (top-left, blue)
  tft.fillRect(TX+6, TY-7, 6, 9, C_PIPEIN);
  tft.drawFastHLine(TX+5, TY-4, 8, C_RIM2);
  tft.drawFastHLine(TX+5, TY-3, 8, C_RIM);

  // Outlet pipe (top-right, orange)
  tft.fillRect(TX+TW-12, TY-7, 6, 9, C_PIPEOUT);
  tft.drawFastHLine(TX+TW-13, TY-4, 8, C_RIM2);
  tft.drawFastHLine(TX+TW-13, TY-3, 8, C_RIM);

  // Drain pipe (bottom-centre)
  tft.fillRect(TX+TW/2-3, TY+TH+1, 7, 7, C_PIPEDRAIN);
  tft.drawFastHLine(TX+TW/2-4, TY+TH+4, 9, C_RIM);

  // Triple rim
  tft.drawRect(TX,   TY,   TW,   TH,   C_RIM);
  tft.drawRect(TX+1, TY+1, TW-2, TH-2, C_RIM2);
  tft.drawRect(TX+2, TY+2, TW-4, TH-4, C_INNER);

  // Sheen edges
  tft.drawFastVLine(TX+3,    TY+5, TH-10, C_RIM2);
  tft.drawFastVLine(TX+TW-4, TY+5, TH-10, C_RIM);
  tft.drawFastHLine(TX+5,    TY+3, TW-10, C_RIM2);
  tft.drawFastHLine(TX+5,    TY+TH-4, TW-10, C_RIM);

  // Horizontal ribs
  int rg = WH/5;
  for(int i=1; i<5; i++){
    int ry = WY + i*rg;
    tft.drawFastHLine(TX+3, ry,   TW-6, C_RIB);
    tft.drawFastHLine(TX+3, ry+1, TW-6, C_RIBHI);
  }

  // Corner rivets (3×3 squares with highlight pixel)
  int rvx[4]={TX+4, TX+TW-5, TX+4,    TX+TW-5};
  int rvy[4]={TY+4, TY+4,    TY+TH-5, TY+TH-5};
  for(int i=0;i<4;i++){
    tft.fillRect(rvx[i]-1, rvy[i]-1, 3, 3, C_RIVET);
    tft.drawPixel(rvx[i]-1, rvy[i]-1, C_RIVHI);
    tft.drawPixel(rvx[i],   rvy[i]-1, C_RIVHI);
  }

  // Scale ticks on right edge
  for(int i=0; i<=4; i++){
    int sy  = WY + (WH*i/4);
    int len = (i%2==0) ? 5 : 3;
    tft.drawFastHLine(TX+TW-3-len, sy, len, C_SCALE);
  }
}

// ── TANK WATER (call every WAVE_MS) ──────────────────────────────────────────
void drawTankWater(){
  int fillH  = (int)(WH * gLevel / 100.0f);
  fillH = constrain(fillH, 0, WH);
  int waterY = WY + WH - fillH;

  // Air space
  if(fillH < WH)
    tft.fillRect(WX, WY, WW, WH-fillH, C_BG);

  // Empty tank
  if(fillH <= 0){
    int rg = WH/5;
    for(int i=1;i<5;i++){
      tft.drawFastHLine(TX+3, WY+i*rg,   TW-6, C_RIB);
      tft.drawFastHLine(TX+3, WY+i*rg+1, TW-6, C_RIBHI);
    }
    return;
  }

  // Water body (deep + mid layers)
  int deepH = (fillH*55)/100;
  tft.fillRect(WX, waterY+fillH-deepH, WW, deepH,       wDeep());
  tft.fillRect(WX, waterY,             WW, fillH-deepH, wMid());

  // Left shimmer
  if(fillH>4)  tft.drawFastVLine(WX,   waterY+2, fillH-4,  wTop());
  if(fillH>8)  tft.drawFastVLine(WX+1, waterY+4, fillH-8,  wMid());

  // Wave pass 1 — main surface
  for(int x=WX; x<WX+WW; x++){
    int dy = (int)(2.5f * sinf((x + wavePhase) * 0.52f));
    int py = waterY + dy;
    if(py>=waterY-3 && py<=waterY+3) safePixel(x, py, wTop());
  }
  // Wave pass 2 — secondary
  for(int x=WX; x<WX+WW; x++){
    int dy = (int)(1.4f * sinf((x + wavePhase*1.3f + 8) * 0.35f));
    int py = waterY + dy - 1;
    if(py>=waterY-4 && py<=waterY+2) safePixel(x, py, wFoam());
  }
  // Wave pass 3 — sparse sparkle
  for(int x=WX; x<WX+WW; x+=4){
    int dy = (int)(sinf((x + wavePhase*0.7f + 15) * 0.6f));
    int py = waterY + dy - 2;
    if(py>=waterY-5 && py<=waterY+1) safePixel(x, py, C_WHITE);
  }

  // Waterline marker tick
  tft.drawFastHLine(TX+TW-7, waterY, 5, C_SCALEA);
  tft.drawPixel(TX+TW-8, waterY, C_SCALEA);

  // Ribs overlaid on water
  int rg = WH/5;
  for(int i=1;i<5;i++){
    int ry = WY + i*rg;
    if(ry>=waterY-1 && ry<=waterY+5){
      tft.drawFastHLine(TX+3, ry,   TW-6, C_RIB);
      tft.drawFastHLine(TX+3, ry+1, TW-6, C_RIBHI);
    }
  }
}

// ── INFO PANEL SKELETON (once at boot) ────────────────────────────────────────
void drawInfoSkeleton(){
  // Header bar
  tft.fillRect(IX, 0, IW, 10, C_HDR_BG);
  tft.drawFastHLine(IX, 10, IW, C_DIV);
  // "TANK" centred  (4 chars × 6px = 24px wide, IW=68 → offset=22)
  drawText("TANK", IX + (IW-24)/2, 3, C_HDR);

  // Section dividers
  tft.drawFastHLine(IX, 46, IW, C_DIV);
  tft.drawFastHLine(IX, 82, IW, C_DIV);
  tft.drawFastHLine(IX,119, IW, C_DIV);

  // Section labels
  drawText("LEVEL", IX+1, 13, C_LBL);
  drawText("TEMPERATURE", IX+1, 49, C_LBL);
  drawText("TDS", IX+1, 85, C_LBL);
}

// ── INFO PANEL VALUES (every sensor read) ─────────────────────────────────────
void drawInfoValues(){
  char buf[12];

  // ── LEVEL ──────────────────────────────────────────────────────────────────
  tft.fillRect(IX, 20, IW, 8, C_PANEL);
  snprintf(buf, sizeof(buf), "%d%%", (int)gLevel);
  drawText(buf, IX+1, 21, C_LVLV);

  // Level bar
  tft.fillRect(IX, 31, IW, 5, C_BAR_BG);
  int bw = constrain((int)(IW * gLevel / 100.0f), 0, IW);
  if(bw>0){
    tft.fillRect(IX, 31, bw, 5, lvlBarCol());
    tft.drawFastHLine(IX, 31, bw, C_MK);   // bright top edge
  }
  if(bw>0 && bw<IW) tft.drawFastVLine(IX+bw, 30, 7, C_MK);

  // cm readout
  tft.fillRect(IX, 38, IW, 7, C_PANEL);
  float distCm = ((100.0f - gLevel) / 100.0f) * 28.0f;
  snprintf(buf, sizeof(buf), "%.1fCM", distCm);
  drawText(buf, IX+1, 38, C_DIM);

  // ── TEMPERATURE ────────────────────────────────────────────────────────────
  tft.fillRect(IX, 57, IW, 8, C_BG);
  // Use '*' as degree symbol (mapped to '°' in font)
  snprintf(buf, sizeof(buf), "%.1f*C", gTemp);
  drawText(buf, IX+1, 58, tCol());

  // Temp bar
  tft.fillRect(IX, 67, IW, 5, C_BAR_BG);
  int tw = (int)(IW * constrain(gTemp, 0.0f, 50.0f) / 50.0f);
  if(tw>0){
    tft.fillRect(IX, 67, tw, 5, tCol());
    tft.drawFastHLine(IX, 67, tw, C_WHITE);
  }
  // Cold / hot threshold markers
  tft.drawFastVLine(IX + (int)(IW*TEMP_COLD/50.0f), 66, 7, C_TMPC);
  tft.drawFastVLine(IX + (int)(IW*TEMP_HOT /50.0f), 66, 7, C_TMPH);

  // Status word
  tft.fillRect(IX, 74, IW, 7, C_BG);
  if(gTemp<=TEMP_COLD){
    drawText("COLD", IX+1, 74, C_TMPC);
  } else if(gTemp>=TEMP_HOT){
    drawText("HOT!", IX+1, 74, C_TMPH);
  } else {
    drawText("OK",   IX+1, 74, C_TDSS);
  }

  // ── TDS ────────────────────────────────────────────────────────────────────
  tft.fillRect(IX, 94, IW, 8, C_BG);
  snprintf(buf, sizeof(buf), "%dp", (int)gTDS);
  drawText(buf, IX+1, 94, dCol());

  // TDS 3-zone bar (300/600/900 scale)
  int s1 = (IW*300)/900;
  int s2 = (IW*600)/900;
  tft.fillRect(IX,    103, s1,    4, C_TBS);
  tft.fillRect(IX+s1, 103, s2-s1, 4, C_TBW);
  tft.fillRect(IX+s2, 103, IW-s2, 4, C_TBD);
  int dm = constrain(IX + (int)(IW * gTDS / 900.0f), IX, IX+IW-1);
  tft.drawFastVLine(dm, 102, 6, C_MK);

  // Status word
  tft.fillRect(IX, 110, IW, 8, C_BG);
  if(gTDS<TDS_SAFE){
    drawText("SAFE", IX+1, 110, C_TDSS);
  } else if(gTDS<TDS_WARN){
    drawText("WARN", IX+1, 110, C_TDSW);
  } else {
    drawText("HIGH", IX+1, 110, C_TDSD);
  }

  // ── Bottom status LEDs ──────────────────────────────────────────────────────
  // Three 4×4 pixel squares: level / temp / tds
  uint16_t dots[3]={
    (gLevel>10) ? C_TDSS : C_TDSD,
    tCol(),
    dCol()
  };
  int dotX[3]={ IX+4, IX+IW/2-2, IX+IW-8 };
  for(int i=0;i<3;i++){
    tft.fillRect(dotX[i], 122, 4, 4, dots[i]);
    tft.drawPixel(dotX[i], 122, C_WHITE);  // highlight corner
  }
}

// ── SENSORS ───────────────────────────────────────────────────────────────────
#if !DEMO_MODE
float readUltrasonic(){
  digitalWrite(TRIG_PIN, LOW);  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  long dur = pulseIn(ECHO_PIN, HIGH, 30000UL);
  if(dur==0) return gDistCm;
  gDistCm = (dur * 0.0343f) / 2.0f;
  return gDistCm;
}

float readTDS(float tempC){
  long sum = 0;
  for(int i=0;i<20;i++){ sum += analogRead(TDS_PIN); delay(5); }
  float v    = (sum/20.0f) * 3.3f / 4095.0f;
  float comp = 1.0f + 0.02f*(tempC-25.0f);
  float cv   = v / comp;
  return constrain(
    (133.42f*cv*cv*cv - 255.86f*cv*cv + 857.39f*cv) * 0.5f,
    0.0f, 9999.0f);
}
#endif

// ── SETUP ─────────────────────────────────────────────────────────────────────
void setup(){
  Serial.begin(115200);
  pinMode(RED_LED, OUTPUT);
 pinMode(GREEN_LED, OUTPUT); 

#if !DEMO_MODE
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  tempSensor.begin();
#endif

  tft.initR(INITR_BLACKTAB);
  tft.setRotation(1);          // LANDSCAPE: 160 wide × 128 tall
  tft.fillScreen(C_BG);

  drawBackground();
  drawTankChrome();
  drawInfoSkeleton();
  drawTankWater();
  drawInfoValues();

#if DEMO_MODE
  Serial.println("=== DEMO MODE — set DEMO_MODE 0 when sensors wired ===");
#endif
}

// ── LOOP ──────────────────────────────────────────────────────────────────────
void loop(){
  unsigned long now = millis();

#if DEMO_MODE
  // Only animate the wave; values stay fixed
  if(now - lastWave >= WAVE_MS){
    lastWave   = now;
    wavePhase  = (wavePhase + 1) % 100;
    drawTankWater();
  }

#else
  // Real sensor reads
  if(now - lastSensor >= SENSOR_MS || firstDraw){
    lastSensor = now;
    firstDraw  = false;

    // Temperature
    tempSensor.requestTemperatures();
    float t = tempSensor.getTempCByIndex(0);
    if(t != DEVICE_DISCONNECTED_C) gTemp = t;

    // TDS
    gTDS = readTDS(gTemp);

    // Ultrasonic → level %
    float dist   = readUltrasonic();
    float newLvl = (TANK_EMPTY_CM - dist) / (TANK_EMPTY_CM - TANK_FULL_CM) * 100.0f;
    newLvl  = constrain(newLvl, 0.0f, 100.0f);
   gLevel  = gLevel * 0.3f + newLvl * 0.7f;
   // ── LED LOGIC ─────────────────────────────

// Condition check
bool isTdsHigh = (gTDS >= TDS_SAFE);
bool isLevelLow = (gLevel < 5);   
bool isTempHigh = (gTemp >= TEMP_HOT);

// Final decision
if (isTdsHigh || isLevelLow || isTempHigh) {
  digitalWrite(RED_LED, HIGH);
  digitalWrite(GREEN_LED, LOW);
} else {
  digitalWrite(RED_LED, LOW);
  digitalWrite(GREEN_LED, HIGH);
}
    drawInfoValues();
    Serial.printf("Temp:%.1fC  TDS:%.0fppm  Level:%.1f%%  Dist:%.1fcm\n",
                  gTemp, gTDS, gLevel, gDistCm);
  }

  if(now - lastWave >= WAVE_MS){
    lastWave  = now;
    wavePhase = (wavePhase+1) % 100;
    drawTankWater();
  }
#endif
}
